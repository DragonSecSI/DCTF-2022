# sweb

SWEB Educational OS

Dependencies: 
 - cmake
 - qemu (qemu-system-x86)
 - gcc (9 or newer)
 - g++ (9 or newer)
