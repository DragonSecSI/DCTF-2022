#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "../../../common/include/kernel/syscall-definitions.h"

extern int sched_yield(void);

#ifdef __cplusplus
}
#endif



