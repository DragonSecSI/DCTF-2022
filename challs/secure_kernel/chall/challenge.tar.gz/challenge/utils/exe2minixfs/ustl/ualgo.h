// WARNING: This is only a dummy header for the exe2minixfs tool!
#ifdef EXE2MINIXFS
#pragma once
#include <algorithm>
#endif
