#include "ProcessRegistry.h"
#include "UserProcess.h"
#include "kprintf.h"
#include "Console.h"
#include "Loader.h"
#include "VfsSyscall.h"
#include "File.h"
#include "ArchMemory.h"
#include "PageManager.h"
#include "ArchThreads.h"
#include "offsets.h"

UserProcess::UserProcess(ustl::string filename, FileSystemInfo *fs_info, char** args, UserProcess* parent, uint32 terminal_number) :
    Thread(fs_info, filename, Thread::USER_THREAD), args(args), parent(parent), fd_(VfsSyscall::open(filename, O_RDONLY))
{
  ProcessRegistry::instance()->processStart(); //should also be called if you fork a process

  if (fd_ >= 0)
    loader_ = new Loader(fd_);

  if (!loader_ || !loader_->loadExecutableAndInitProcess())
  {
    debug(USERPROCESS, "Error: loading %s failed!\n", filename.c_str());
    kill();
    return;
  }

  size_t page_for_stack = PageManager::instance()->allocPPN();
  bool vpn_mapped = loader_->arch_memory_.mapPage(USER_BREAK / PAGE_SIZE - 1, page_for_stack, 1);
  assert(vpn_mapped && "Virtual page for stack was already mapped - this should never happen");

  ArchThreads::createUserRegisters(user_registers_, loader_->getEntryFunction(),
                                   (void*) (USER_BREAK - sizeof(pointer)),
                                   getKernelStackStartPointer());

  ArchThreads::setAddressSpace(this, loader_->arch_memory_);

  debug(USERPROCESS, "ctor: Done loading %s\n", filename.c_str());

  if (main_console->getTerminal(terminal_number))
    setTerminal(main_console->getTerminal(terminal_number));



  switch_to_userspace_ = args ? 0 : 1;
}

UserProcess::~UserProcess()
{
  assert(Scheduler::instance()->isCurrentlyCleaningUp());
  delete loader_;
  loader_ = 0;

  if (fd_ > 0)
    VfsSyscall::close(fd_);

  delete working_dir_;
  working_dir_ = 0;

  ProcessRegistry::instance()->processExit();
}

void UserProcess::Run()
{
  if(args == 0)
  {
      debug(USERPROCESS, "Run: Fail-safe kernel panic - you probably have forgotten to set switch_to_userspace_ = 1\n");
      assert(false);
  }

  size_t arg_page = PageManager::instance()->allocPPN();
  char* arg_addr = (char*)(USER_BREAK / 2ULL);
  bool x = loader_->arch_memory_.mapPage((size_t)arg_addr / PAGE_SIZE, arg_page, 1);

  assert(x);

  ArchMemoryMapping arr_mapping = parent->loader_->arch_memory_.resolveMapping((size_t)args/PAGE_SIZE);

  if(arr_mapping.page != NULL)
  {
      char** args_arr = (char**)(((char*)arr_mapping.page) + (size_t) args % PAGE_SIZE);
      int len = 0;
      while(args_arr[len] != 0)
      {

          len++;
      }
      debug(SYSCALL, "Length is %d\n", len);
      char* string_ptr = arg_addr + (len + 1) * sizeof(char*);
      for(int i = 0; i < len; i++)
      {
          ArchMemoryMapping sm = parent->loader_->arch_memory_.resolveMapping((size_t)args_arr[i]/PAGE_SIZE);
          char* str_ptr = (char*)sm.page + (size_t) args_arr[i] % PAGE_SIZE;
          size_t strl = strlen(str_ptr);
          char* addr = strncpy(string_ptr, str_ptr, strl);
          ((char**)arg_addr)[i] = addr;
          string_ptr += strl;
      }
      ((char**)arg_addr)[len] = 0;
      user_registers_->rsi = (size_t)arg_addr;
      user_registers_->rdi = len;
  }



  switch_to_userspace_ = 1;
  Scheduler::instance()->yield();

}

