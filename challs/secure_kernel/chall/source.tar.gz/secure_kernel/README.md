# sweb

SWEB Educational OS

Dependencies: 
 - cmake
 - qemu (qemu-system-x86)
 - gcc (9 or newer)
 - g++ (9 or newer)

How to run:

```
mkdir -p /tmp/sweb
cd /tmp/sweb
cmake {PATH_TO_SOURCE}
make -j
make qemu
```
