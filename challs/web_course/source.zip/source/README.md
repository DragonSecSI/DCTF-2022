
run with 

npm install 

docker-compose -f "source/docker-compose.yml" up -d --build